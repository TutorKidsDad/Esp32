#ifndef PINS_H
#define PINS_H

#define TCS_ADDR      0x29
#define AHT20_ADDR    0x38  
#define OLED_ADDR     0x3C  

#define SCL 22
#define SDA 21

#define R_LED 27
#define G_LED 13
#define B_LED 12

#define STRIP_LED 14
#define MOISTURE_IN 34
#define V_BATT 32
#define BUZZER 26

#endif
