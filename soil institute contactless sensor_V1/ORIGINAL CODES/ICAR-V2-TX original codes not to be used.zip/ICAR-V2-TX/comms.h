#ifndef COMMS_H
#define COMMS_H

#include <WiFi.h>
#include "Adafruit_MQTT.h"
#include "Adafruit_MQTT_Client.h"

#define AIO_SERVER      "io.adafruit.com"
#define AIO_SERVERPORT  1883
#define AIO_USERNAME  "MEGH_SNB"
#define AIO_KEY       "aio_lqiU2710gTGLZ6zrY5PWBwTZxeP0"

#define BAUD_RATE 115200

#define WIFI_SSID "PHENIX-AX10"
#define WIFI_PASS "03323359065"

WiFiClient client;
Adafruit_MQTT_Client mqtt(&client, AIO_SERVER, AIO_SERVERPORT, AIO_USERNAME, AIO_KEY);

#ifdef DEV_ID0
  #define DEV_ID 0
  #define DEV_NAME "MEGH-TX0"
  Adafruit_MQTT_Publish feed_wp       = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/wp_0");
  Adafruit_MQTT_Publish feed_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_0");
  Adafruit_MQTT_Publish feed_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_0");
  Adafruit_MQTT_Publish feed_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_0");
  Adafruit_MQTT_Publish feed_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_0");
  Adafruit_MQTT_Publish feed_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_0");
#endif

#ifdef DEV_ID1
  #define DEV_ID 1
  #define DEV_NAME "MEGH-TX1"
  Adafruit_MQTT_Publish feed_wp       = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/wp_1");
  Adafruit_MQTT_Publish feed_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_1");
  Adafruit_MQTT_Publish feed_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_1");
  Adafruit_MQTT_Publish feed_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_1");
  Adafruit_MQTT_Publish feed_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_1");
  Adafruit_MQTT_Publish feed_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_1");
#endif

#ifdef DEV_ID2
  #define DEV_ID 2
  #define DEV_NAME "MEGH-TX2"
  Adafruit_MQTT_Publish feed_wp       = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/wp_2");
  Adafruit_MQTT_Publish feed_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_2");
  Adafruit_MQTT_Publish feed_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_2");
  Adafruit_MQTT_Publish feed_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_2");
  Adafruit_MQTT_Publish feed_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_2");
  Adafruit_MQTT_Publish feed_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_2");
#endif

#ifdef DEV_ID3
  #define DEV_ID 3
  #define DEV_NAME "MEGH-TX3"
  Adafruit_MQTT_Publish feed_wp       = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/wp_3");
  Adafruit_MQTT_Publish feed_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_3");
  Adafruit_MQTT_Publish feed_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_3");
  Adafruit_MQTT_Publish feed_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_3");
  Adafruit_MQTT_Publish feed_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_3");
  Adafruit_MQTT_Publish feed_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_3");
#endif


/*Adafruit_MQTT_Publish feed_wp       = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/wp_0");
Adafruit_MQTT_Publish feed_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_0");
Adafruit_MQTT_Publish feed_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_0");
Adafruit_MQTT_Publish feed_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_0");
Adafruit_MQTT_Publish feed_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_0");
Adafruit_MQTT_Publish feed_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_0");
*/

//Adafruit_MQTT_Publish feed_wp       = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/wp_1");
/*Adafruit_MQTT_Publish feed_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_"+DEV_ID);
Adafruit_MQTT_Publish feed_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_"+DEV_ID);
Adafruit_MQTT_Publish feed_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_"+DEV_ID);
Adafruit_MQTT_Publish feed_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_"+DEV_ID);
Adafruit_MQTT_Publish feed_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_"+DEV_ID);
*/
#include "sensors.h"
void MQTT_connect()
{
  int8_t ret;
  if (mqtt.connected()) 
    return;
  Serial.print("Connecting to MQTT... ");
  uint8_t retries = 3;
  while ((ret = mqtt.connect()) != 0) 
  { 
    Serial.println(mqtt.connectErrorString(ret));
    Serial.println("Retrying MQTT connection in 5 seconds...");
    mqtt.disconnect();
    delay(5000);
    retries--;
    if (retries == 0) 
      while (1);
  }
  Serial.println("MQTT Connected!");
}

void upload_data()
{
  //MQTT_connect();
  if (!feed_wp.publish(wp)) 
    Serial.println("Upload Failed!");

  /*
  if (!feed_humidity.publish(humidity)) 
    Serial.println("Upload Failed!");

  if (!feed_temp.publish(temp)) 
    Serial.println("Upload Failed!");

  if (!feed_moisture.publish(moisture)) 
    Serial.println("Upload Failed!");

  if (!feed_vbatt.publish(battery_v)) 
    Serial.println("Upload Failed!");
  */
  digitalWrite(BUZZER, HIGH);
  delay(10);
  digitalWrite(BUZZER, LOW);
}
#endif