#ifndef DISPLAY_H
#define DISPLAY_H

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_RESET -1   //   QT-PY / XIAO

Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
int active_screen = 0;
hw_timer_t *timer = NULL;

// attach toggle switch with interrupts for switching the display modes 

void IRAM_ATTR switch_screen()
{
  active_screen = (active_screen+1)%2;
}

void init_display()
{
  display.begin(OLED_ADDR, true);
  delay(2000);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(40, 30);
  display.print(DEV_NAME);
  display.display();
  
  timer = timerBegin(0, 80, true);
  timerAttachInterrupt(timer, &switch_screen, true);
  timerAlarmWrite(timer, 5000000, true);
  timerAlarmEnable(timer);
}

void display_icons()
{
  int y=50, x=10, p =25, q=8, b, len = 40, x1;
  b = p-(vbatt - 3.3)/0.9*p + 1;
  display.drawRoundRect(x, y, p, q,1, 1);
  display.fillRect(x+p, y+1,1, q-2, 1);
  display.fillRect(x+1, y, p-b, q, 1);
  display.display();
}
void update_screen()
{
  int x = 10, offset=15, y = 70;

  display.clearDisplay();
  //display.setCursor(40, 0);
  //display.print(DEV_NAME);

  display.setCursor(30, 10);
  display.print(WiFi.localIP());
  //display.print("MEGH");


  // add options for sub menu here
  // bring these down
  if(active_screen == 0)
  {
    display.setCursor(5, x*1+offset);
    display.print("WP :"+String(wp));

    display.setCursor(5, x*2+offset);
    display.print("TMP:"+String(temp)+"C");

    display.setCursor(y, x*1+offset);
    display.print("RH :"+String(humidity));

    display.setCursor(y, x*2+offset);
    display.print("MOS:"+String(moisture)+"%");
  }
  else if(active_screen == 1)
  {
    display.setCursor(5, x*1+offset);
    display.print("STRIP:"+strip);

    // add battery icon below 
  }
  display_icons();
  display.display();     
}


// add battery icon functions
#endif