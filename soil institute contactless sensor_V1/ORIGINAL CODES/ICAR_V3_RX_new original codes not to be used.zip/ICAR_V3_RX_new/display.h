#ifndef DISPLAY_H
#define DISPLAY_H

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include "sensors.h"

//#define SCREEN_WIDTH 128 // OLED display width, in pixels
//#define SCREEN_HEIGHT 64 // OLED display height, in pixels
//#define OLED_RESET -1   //   QT-PY / XIAO

//void init_display();
//void display_icons();
//void update_screen();


//Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
//int active_screen = 0;
hw_timer_t *timer = NULL;

// attach toggle switch with interrupts for switching the display modes 

/*
void IRAM_ATTR switch_screen()
{
  active_screen = (active_screen+1)%5;
 //Serial.println("Screen swapp" + String(active_screen));
  update_screen();
}*/
void switch_screen()
{
  active_screen = (active_screen+1)%5;
 //Serial.println("Screen swapp" + String(active_screen));
  update_screen();
}

//void init_display()
{
  display.begin(OLED_ADDR, true);
  delay(2000);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(40, 30);
  display.print(DEV_NAME);
  display.display();
  
  /*
  timer = timerBegin(0, 80, true);
  timerAttachInterrupt(timer, &switch_screen, true);
  timerAlarmWrite(timer, 5000000, true);
  timerAlarmEnable(timer);
  */
}
//void display_icons()
{
  int y=50, x=10, p =25, q=8, b, len = 40, x1;
  //b = p-(v_batt - 11.63)/0.9*p + 1;
  b = p-(v_batt - 11.86)/0.9*p + 1+2;
  display.drawRoundRect(x, y, p, q,1, 1);
  display.fillRect(x+p, y+1,1, q-2, 1);
  display.fillRect(x+1, y, p-b, q, 1); //charge bar
  //display.display();
}
//void update_screen()
{
  int x = 10, offset=15, y = 70;

  //display.clearDisplay();
  //display.setCursor(40, 0);
  //display.print(DEV_NAME);

  //display.setCursor(30, 10);
  //display.print(WiFi.localIP());


  //if(active_screen == 0)
  {
    display.clearDisplay();
    display.setCursor(40, 0);
    if(millis() - ts0 > TIMEOUT)
    {
      display.print("TX0-Offline");
      display.display();
      switch_screen();
      return;
    }
    display.print("TX0-data");

    display.setCursor(5, x*1+offset);
    display.print("WP :"+String(wp0));

    display.setCursor(5, x*2+offset);
    display.print("HUM:"+String(humidity0)+"%");

    display.setCursor(5, x*3+offset);
    display.print("TMP:"+String(temp0)+"C");

    display.setCursor(y, x*1+offset);
    display.print("BAT:"+String(vbatt0));

    display.setCursor(y, x*2+offset);
    display.print("MOS:"+String(moisture0)+"%");

    display.setCursor(y, x*3+offset);
    display.print("ST:"+String(strip0));
  }
  //else if(active_screen == 1)
  {    
    display.clearDisplay();
    display.setCursor(40, 0);
    if(millis() - ts1 > TIMEOUT)
    {
      display.print("TX1-Offline");
      display.display();
      active_screen = (active_screen+1)%5;
      switch_screen();
      return;
    }
    display.print("TX1-Data");

    display.setCursor(5, x*1+offset);
    display.print("WP :"+String(wp1));

    display.setCursor(5, x*2+offset);
    display.print("HUM:"+String(humidity1)+"%");

    display.setCursor(5, x*3+offset);
    display.print("TMP:"+String(temp1)+"C");

    display.setCursor(y, x*1+offset);
    display.print("BAT:"+String(vbatt1));

    display.setCursor(y, x*2+offset);
    display.print("MOS:"+String(moisture1)+"%");

    display.setCursor(y, x*3+offset);
    display.print("ST:"+String(strip1));
  }
  //else if(active_screen == 2)
  {
    display.clearDisplay();
    display.setCursor(40, 0);
    if(millis() - ts2 > TIMEOUT)
    {
      display.print("TX2-Offline");
      display.display();
      switch_screen();
      return;
    }
    //display.print("TX2-Data");

    //display.setCursor(5, x*1+offset);
    //display.print("WP :"+String(wp2));

    //display.setCursor(5, x*2+offset);
    //display.print("HUM:"+String(humidity2)+"%");

    //display.setCursor(5, x*3+offset);
    //display.print("TMP:"+String(temp2)+"C");

    //display.setCursor(y, x*1+offset);
    //display.print("BAT:"+String(vbatt2));

    //display.setCursor(y, x*2+offset);
    //display.print("MOS:"+String(moisture2)+"%");

    //display.setCursor(y, x*3+offset);
    //display.print("ST:"+String(strip2));
  }
  //else if(active_screen == 3)
  {
    //display.clearDisplay();
   // display.setCursor(40, 0);
    if(millis() - ts3 > TIMEOUT)
    {
      //display.print("TX3-Offline");
     // display.display();
      //switch_screen();
      return;
    }
    //display.print("TX3-Data");

    //display.setCursor(5, x*1+offset);
   // display.print("WP :"+String(wp3));

    //display.setCursor(5, x*2+offset);
    //display.print("HUM:"+String(humidity3)+"%");

    //display.setCursor(5, x*3+offset);
    //display.print("TMP:"+String(temp3)+"C");

    //display.setCursor(y, x*1+offset);
   // display.print("BAT:"+String(vbatt3));

    //display.setCursor(y, x*2+offset);
    //display.print("MOS:"+String(moisture3)+"%");

    //display.setCursor(y, x*3+offset);
    //display.print("ST:"+String(strip3));
  }
  //else if(active_screen == 4)
  {
    display.clearDisplay();
    display_icons();
    display.setCursor(40, 0);
    display.print("MEGH-RX");

    display.setCursor(5, x*1+offset);
    if(v_batt < 11.63)
    display.print("BAT : "+String(v_batt)+"L");
    else
    display.print("BAT :"+String(v_batt)+"V");

    display.setCursor(5, x*2+offset);
    display.print("PSU:"+String(String(v_psu)+"V"));

    display.setCursor(y+40, x*1+offset);
    if(v0)
      display.print("V0");

    display.setCursor(y+40, x*2+offset);
    if(v1)
      display.print("V1");

    display.setCursor(y+40, x*3+offset);
    if(v2)
      display.print("V2");

    display.setCursor(y+40, x*4+offset);
    if(v3)
      display.print("V3");

  }
  //display_icons();
 // display.display();     
}


// add battery icon functions
#endif