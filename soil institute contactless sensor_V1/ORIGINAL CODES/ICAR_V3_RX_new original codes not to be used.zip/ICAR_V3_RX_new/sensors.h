#ifndef SENSORS_H
#define SENSORS_H

#include <Wire.h>
#include "pins.h"
#include "comms.h"
#include "Adafruit_TCS34725.h"

 
#define THRESHOLD_WP -57.00
//#define THRESHOLD_WP0 THRESHOLD_WP
//#define THRESHOLD_WP1 THRESHOLD_WP
#define THRESHOLD_WP2 THRESHOLD_WP
#define THRESHOLD_WP3 THRESHOLD_WP

float v_batt, v_psu;
int v0, v1, v2, v3;
int psu_swap_t, psu_en = 0;
//int pump_en = 0; // turn this to 1 to activate the pump

void read_voltage();

void turn_relay_off()
{
  
  //digitalWrite(PUMP, LOW);
 //digitalWrite(VALVE0, LOW);
  //digitalWrite(VALVE1, LOW);
  digitalWrite(VALVE2, LOW);
  digitalWrite(VALVE3, LOW);
}

void init_pins()
{
  //pinMode(VALVE0, OUTPUT);
  //pinMode(VALVE1, OUTPUT);
  pinMode(VALVE2, OUTPUT);
  pinMode(VALVE3, OUTPUT);
  //pinMode(PUMP, OUTPUT);
  pinMode(PWR_SW, OUTPUT);
  digitalWrite(PWR_SW, LOW);

  turn_relay_off();
  v_batt = 12.23;
}

void switch_valves()
{
    //if(wp0 > THRESHOLD_WP0 && millis() - ts0 < TIMEOUT)
    {
      v0 = 1;
      //digitalWrite(VALVE0, HIGH);
    }
    //else
    {
      v0 = 0;
      //digitalWrite(VALVE0, LOW);
    }
      
   // if(wp1 > THRESHOLD_WP1 && millis() - ts1 < TIMEOUT)
    {
      v1 = 1;
      //digitalWrite(VALVE1, HIGH);
    }
   // else
    {
      v1 = 0;
      //digitalWrite(VALVE1, LOW);
    }

    if(wp2 > THRESHOLD_WP2 && millis() - ts2 < TIMEOUT)
    {
      v2 = 1;
      digitalWrite(VALVE2, HIGH);
    }
    else
    {
      v2 = 0;
      digitalWrite(VALVE2, LOW);
    }

    if(wp3 > THRESHOLD_WP3 && millis() - ts3 < TIMEOUT)
    {
      v3 = 1;
      digitalWrite(VALVE3, HIGH);
    }
    else
    {
      v3 = 0;
      digitalWrite(VALVE3, LOW);
    }
}
void read_voltage()
{
  v_batt = (v_batt + analogRead(V_BATT)*3.3*6.82 /4096)/2.0;
  v_psu  = analogRead(V_PSU)*3.3*7.60/4096;
  if(v_psu < 8.0)
    v_psu = 0.0;

  //Serial.println(String(v_batt)+" "+String(analogRead(V_BATT))+" "+String(analogRead(V_PSU))+" "+String(v_psu));
  
  if(v_psu >= 10.5 && millis() - psu_swap_t > 5000 && psu_en == 0)
  {
    psu_en = 1;
    psu_swap_t = millis();
    turn_relay_off();
    delay(300);
    digitalWrite(PWR_SW, HIGH);
    delay(300);     
    switch_valves();
    //Serial.println("PSU Swapped");
  }
  else if(v_psu < 10.5)
  {
    psu_en = 0;
    digitalWrite(PWR_SW, LOW);
    //Serial.println("Battery Swapped");
  }
  Serial.println("v_batt : "+String(v_batt)+" v_psu : "+String(v_psu));
}
//void check_pump()
//{
  int x = analogRead(WL_SENSE0);
  //Serial.println(x);
  //if(x < 3500 && pump_en == 1)
  //{// turn off all valves here maybe?
    //turn_relay_off();
    //Serial.println("Pump on ");
    //digitalWrite(PUMP, HIGH);
    //delay(60000*6);
    //digitalWrite(PUMP, LOW);
    //switch_valves();
    // turn em back on acc to v(x)
 // }
//}

#endif
