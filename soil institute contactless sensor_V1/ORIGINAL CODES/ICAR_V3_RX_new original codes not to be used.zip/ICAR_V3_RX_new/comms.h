#ifndef COMMS_H
#define COMMS_H

#include <WiFi.h>
#include "AdafruitIO_WiFi.h"

#define IO_USERNAME  "MEGH_SNB"
#define IO_KEY       "aio_lqiU2710gTGLZ6zrY5PWBwTZxeP0"

#define WIFI_SSID "PHENIX-AX10"
#define WIFI_PASS "03323359065"

#define BAUD_RATE 115200
#define TIMEOUT 10000

//void tx0_callback(AdafruitIO_Data *data);
//void tx1_callback(AdafruitIO_Data *data);
void tx2_callback(AdafruitIO_Data *data);
void tx3_callback(AdafruitIO_Data *data);


AdafruitIO_WiFi io(IO_USERNAME, IO_KEY, WIFI_SSID, WIFI_PASS);

float wp0=0.0, humidity0=0.0, temp0=0.0, vbatt0=0.0, moisture0=0.0; String strip0="001122";
float wp1=0.0, humidity1=0.0, temp1=0.0, vbatt1=0.0, moisture1=0.0; String strip1="001122";
float wp2=0.0, humidity2=0.0, temp2=0.0, vbatt2=0.0, moisture2=0.0; String strip2="001122";
float wp3=0.0, humidity3=0.0, temp3=0.0, vbatt3=0.0, moisture3=0.0; String strip3="001122";

int ts0, ts1, ts2, ts3;

//AdafruitIO_Feed *feed0_wp       = io.feed("wp-0");
/*
Adafruit_MQTT_Subscribe feed0_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_0");
Adafruit_MQTT_Subscribe feed0_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_0");
Adafruit_MQTT_Subscribe feed0_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_0");
Adafruit_MQTT_Subscribe feed0_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_0");
Adafruit_MQTT_Subscribe feed0_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_0");
*/

//AdafruitIO_Feed *feed1_wp       = io.feed("wp-1");
/*
Adafruit_MQTT_Subscribe feed1_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_1");
Adafruit_MQTT_Subscribe feed1_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_1");
Adafruit_MQTT_Subscribe feed1_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_1");
Adafruit_MQTT_Subscribe feed1_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_1");
Adafruit_MQTT_Subscribe feed1_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_1");
*/

AdafruitIO_Feed *feed2_wp       =  io.feed("wp_2");
/*
Adafruit_MQTT_Subscribe feed2_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_2");
Adafruit_MQTT_Subscribe feed2_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_2");
Adafruit_MQTT_Subscribe feed2_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_2");
Adafruit_MQTT_Subscribe feed2_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_2");
Adafruit_MQTT_Subscribe feed2_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_2");
*/

AdafruitIO_Feed *feed3_wp       = io.feed("wp_3");
/*
Adafruit_MQTT_Subscribe feed3_humidity = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/humidity_3");
Adafruit_MQTT_Subscribe feed3_temp     = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/temp_3");
Adafruit_MQTT_Subscribe feed3_color    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/color_3");
Adafruit_MQTT_Subscribe feed3_vbatt    = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/v_batt_3");
Adafruit_MQTT_Subscribe feed3_moisture = Adafruit_MQTT_Publish(&mqtt, AIO_USERNAME "/feeds/soil_moisture_3");
*/
void MQTT_connect()
{
  ts0 = ts1 = ts2 = ts3 = 0;
  io.connect();
  Serial.print("Connecting to MQTT... \n");


  while(io.mqttStatus() < AIO_CONNECTED) 
  {
    Serial.print(".");
    delay(500);
  }
  Serial.println("\nAIO Connected!");

 // feed0_wp->onMessage(tx0_callback);
 // feed1_wp->onMessage(tx1_callback);
  feed2_wp->onMessage(tx2_callback);
  feed3_wp->onMessage(tx3_callback);

 // feed0_wp->get();
  //feed1_wp->get();
  feed2_wp->get();
  feed3_wp->get();
}

void tx0_callback(AdafruitIO_Data *data)
{
  ts0 = millis();
  wp0           = data->toFloat();
  /*humidity0     = 
  temp0         =
  vbatt0        =
  moisture0     =
  String strip0 =*/

  Serial.println("WP0 - "+String(wp0));
}
void tx1_callback(AdafruitIO_Data *data)
{
  ts1 = millis();
  wp1           = data->toFloat();
  /*humidity0     = 
  temp0         =
  vbatt0        =
  moisture0     =
  String strip0 =*/
  Serial.println("WP1 - "+String(wp1));
}
void tx2_callback(AdafruitIO_Data *data)
{
  ts2 = millis();
  wp2           = data->toFloat();
  /*humidity0     = 
  temp0         =
  vbatt0        =
  moisture0     =
  String strip0 =*/
  Serial.println("WP2 - "+String(wp2));
}
void tx3_callback(AdafruitIO_Data *data)
{
  ts3 = millis();
  wp3           = data->toFloat();
  /*humidity0     = 
  temp0         =
  vbatt0        =
  moisture0     =
  String strip0 =*/
  Serial.println("WP3 - "+String(wp3));
}

bool check_server()
{
  // check for data 
  //
}
#endif